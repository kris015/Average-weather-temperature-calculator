<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<p>Unesite izmjerene temperature odvojene zarezom</p>
<form action='vjezba4.php' method="GET">
        <input type="text" name="temperature">
        
        <button name='subimt'>Izracunaj</button>

        <?php
$izm_temp = $_GET['temperature'];
$temp_array = explode(',', $izm_temp);
$tot_temp = 0;
$br_iz_temp = count($temp_array);
foreach($temp_array as $temp)
{
 $tot_temp += $temp;
}
echo "<br>";
echo "Broj mjerenih dana: ".$br_iz_temp."<br>";

 $pros_temp = $tot_temp/$br_iz_temp;
 echo "Prosjecna temperatura : ".$pros_temp."<br>
"; 
sort($temp_array);
echo " Pet najnizih temperatura :";
for ($i=0; $i< 5; $i++)
{ 
echo $temp_array[$i].", ";
}
echo "<br>";
echo "Pet najvecih temperatura :";
for ($i=($br_iz_temp-5); $i< ($br_iz_temp); $i++)
{
echo $temp_array[$i].", ";
}
?>

</body>
</html>